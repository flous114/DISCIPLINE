package com.discipline.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Book
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Gamepad
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlin.math.roundToInt

private val Cream = Color(0xFFF7F7F0)
private val SurfaceWhite = Color(0xFFFFFEFA)
private val Sage = Color(0xFF8EAD91)
private val SageDark = Color(0xFF557A5C)
private val SagePale = Color(0xFFE7EFE4)
private val Ink = Color(0xFF263229)
private val Muted = Color(0xFF788279)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val vm: StudyViewModel = viewModel()
            DisciplineTheme {
                DisciplineScreen(vm)
            }
        }
    }
}

@Composable
private fun DisciplineTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = SageDark,
            onPrimary = Color.White,
            secondary = Sage,
            background = Cream,
            surface = SurfaceWhite,
            onSurface = Ink,
            onBackground = Ink
        ),
        typography = Typography(),
        content = content
    )
}

@Composable
private fun DisciplineScreen(vm: StudyViewModel) {
    val state by vm.uiState.collectAsState()
    val progress by animateFloatAsState(
        targetValue = state.progress,
        animationSpec = tween(650),
        label = "timerProgress"
    )

    Surface(modifier = Modifier.fillMaxSize(), color = Cream) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 22.dp, vertical = 18.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("DISCIPLINE", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = SageDark, letterSpacing = 2.sp)
                    Text("把时间还给重要的事。", fontSize = 13.sp, color = Muted)
                }
                Box(
                    modifier = Modifier.size(42.dp).clip(CircleShape).background(SagePale),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Rounded.CheckCircle, contentDescription = null, tint = SageDark)
                }
            }

            AnimatedContent(
                targetState = state.phase,
                transitionSpec = { fadeIn(tween(280)) togetherWith fadeOut(tween(180)) },
                label = "phaseCard"
            ) { phase ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(28.dp),
                    colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(22.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(
                                if (phase == StudyPhase.FOCUS) Icons.Rounded.Book else Icons.Rounded.Gamepad,
                                contentDescription = null,
                                tint = SageDark
                            )
                            Text(
                                if (phase == StudyPhase.FOCUS) "专注时间" else if (state.mode == StudyMode.NORMAL) "娱乐时间" else "休息时间",
                                color = SageDark,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                        Text(
                            text = formatTime(state.remainingSeconds),
                            fontSize = 54.sp,
                            fontWeight = FontWeight.Light,
                            color = Ink,
                            letterSpacing = 1.sp
                        )
                        LinearProgressIndicator(
                            progress = { progress },
                            modifier = Modifier.fillMaxWidth().height(7.dp).clip(CircleShape),
                            color = Sage,
                            trackColor = SagePale
                        )
                        Text(
                            "第 ${if (state.isFinished) state.totalCycles else state.completedCycles + 1} / ${state.totalCycles} 轮",
                            fontSize = 13.sp,
                            color = Muted
                        )
                    }
                }
            }

            Text("选择计划", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Ink)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ModeCard(
                    title = "普通模式",
                    subtitle = "30 分钟学习 · 20 分钟娱乐",
                    selected = state.mode == StudyMode.NORMAL,
                    modifier = Modifier.weight(1f),
                    enabled = !state.isRunning && !state.hasStarted
                ) { vm.selectMode(StudyMode.NORMAL) }
                ModeCard(
                    title = "狂学模式",
                    subtitle = "60 分钟学习 · 10 分钟休息",
                    selected = state.mode == StudyMode.INTENSE,
                    modifier = Modifier.weight(1f),
                    enabled = !state.isRunning && !state.hasStarted
                ) { vm.selectMode(StudyMode.INTENSE) }
            }
            ModeCard(
                title = "自定义模式",
                subtitle = "自己设定学习与休息时长",
                selected = state.mode == StudyMode.CUSTOM,
                modifier = Modifier.fillMaxWidth(),
                enabled = !state.isRunning && !state.hasStarted
            ) { vm.selectMode(StudyMode.CUSTOM) }

            if (state.mode == StudyMode.CUSTOM && !state.hasStarted) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
                    shape = RoundedCornerShape(22.dp)
                ) {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("学习时长：${state.customFocusMinutes} 分钟", fontWeight = FontWeight.SemiBold)
                        Slider(
                            value = state.customFocusMinutes.toFloat(),
                            onValueChange = { vm.setCustomFocus(it.roundToInt()) },
                            valueRange = 5f..180f,
                            steps = 34
                        )
                        Text("休息时长：${state.customBreakMinutes} 分钟", fontWeight = FontWeight.SemiBold)
                        Slider(
                            value = state.customBreakMinutes.toFloat(),
                            onValueChange = { vm.setCustomBreak(it.roundToInt()) },
                            valueRange = 1f..60f,
                            steps = 58
                        )
                    }
                }
            }

            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
                shape = RoundedCornerShape(22.dp)
            ) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("循环次数", fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                        Text("${state.totalCycles} 轮", color = SageDark, fontWeight = FontWeight.Bold)
                    }
                    Slider(
                        value = state.totalCycles.toFloat(),
                        onValueChange = { vm.setCycles(it.roundToInt()) },
                        valueRange = 1f..20f,
                        steps = 18,
                        enabled = !state.isRunning
                    )
                    Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Text("1 轮", fontSize = 11.sp, color = Muted)
                        Text("最多 20 轮", fontSize = 11.sp, color = Muted)
                    }
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = { if (state.isRunning) vm.pause() else vm.startOrResume() },
                    modifier = Modifier.weight(1f).height(54.dp),
                    shape = RoundedCornerShape(17.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = SageDark)
                ) {
                    Icon(if (state.isRunning) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, contentDescription = null)
                    Spacer(Modifier.width(7.dp))
                    Text(if (state.isRunning) "暂停计划" else if (state.hasStarted) "继续计划" else "开始计划")
                }
                OutlinedButton(
                    onClick = vm::reset,
                    modifier = Modifier.height(54.dp),
                    shape = RoundedCornerShape(17.dp),
                    enabled = state.hasStarted
                ) {
                    Icon(Icons.Rounded.Refresh, contentDescription = "重置")
                    Spacer(Modifier.width(4.dp))
                    Text("重置")
                }
            }

            if (state.isFinished) {
                Card(colors = CardDefaults.cardColors(containerColor = SagePale), shape = RoundedCornerShape(18.dp)) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.CheckCircle, tint = SageDark, contentDescription = null)
                        Spacer(Modifier.width(10.dp))
                        Text("计划完成。今天的努力，已经记下了。", color = Ink, fontWeight = FontWeight.Medium)
                    }
                }
            }

            Text(
                "V0.1 · 本地计时原型。应用限制、密码与通知将在后续版本接入。",
                fontSize = 11.sp,
                color = Muted,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
            )
        }
    }
}

@Composable
private fun ModeCard(
    title: String,
    subtitle: String,
    selected: Boolean,
    modifier: Modifier = Modifier,
    enabled: Boolean,
    onClick: () -> Unit
) {
    val bg by animateColorAsStateCompat(if (selected) SagePale else SurfaceWhite)
    Card(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier,
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = bg),
        border = if (selected) androidx.compose.foundation.BorderStroke(1.dp, Sage) else null
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Text(title, fontWeight = FontWeight.Bold, color = if (selected) SageDark else Ink, fontSize = 14.sp)
            Text(subtitle, color = Muted, fontSize = 11.sp, lineHeight = 16.sp)
        }
    }
}

@Composable
private fun animateColorAsStateCompat(target: Color): State<Color> =
    animateColorAsState(targetValue = target, animationSpec = tween(250), label = "cardColor")

private fun formatTime(seconds: Long): String {
    val safe = seconds.coerceAtLeast(0)
    val hours = safe / 3600
    val minutes = (safe % 3600) / 60
    val secs = safe % 60
    return if (hours > 0) "%02d:%02d:%02d".format(hours, minutes, secs)
    else "%02d:%02d".format(minutes, secs)
}
