package com.discipline.app

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

enum class StudyMode { NORMAL, INTENSE, CUSTOM }
enum class StudyPhase { FOCUS, BREAK }

data class StudyUiState(
    val mode: StudyMode = StudyMode.NORMAL,
    val phase: StudyPhase = StudyPhase.FOCUS,
    val totalCycles: Int = 2,
    val completedCycles: Int = 0,
    val customFocusMinutes: Int = 30,
    val customBreakMinutes: Int = 20,
    val remainingSeconds: Long = 30 * 60L,
    val phaseDurationSeconds: Long = 30 * 60L,
    val isRunning: Boolean = false,
    val hasStarted: Boolean = false,
    val isFinished: Boolean = false
) {
    val progress: Float
        get() = if (phaseDurationSeconds <= 0) 0f
        else (1f - remainingSeconds.toFloat() / phaseDurationSeconds).coerceIn(0f, 1f)
}

class StudyViewModel : ViewModel() {
    private val _uiState = MutableStateFlow(StudyUiState())
    val uiState: StateFlow<StudyUiState> = _uiState.asStateFlow()
    private var timerJob: Job? = null

    private fun focusSeconds(state: StudyUiState = _uiState.value): Long = when (state.mode) {
        StudyMode.NORMAL -> 30 * 60L
        StudyMode.INTENSE -> 60 * 60L
        StudyMode.CUSTOM -> state.customFocusMinutes * 60L
    }

    private fun breakSeconds(state: StudyUiState = _uiState.value): Long = when (state.mode) {
        StudyMode.NORMAL -> 20 * 60L
        StudyMode.INTENSE -> 10 * 60L
        StudyMode.CUSTOM -> state.customBreakMinutes * 60L
    }

    fun selectMode(mode: StudyMode) {
        if (_uiState.value.isRunning || _uiState.value.hasStarted) return
        _uiState.update { old ->
            val next = old.copy(mode = mode, phase = StudyPhase.FOCUS)
            val focus = focusSeconds(next)
            next.copy(remainingSeconds = focus, phaseDurationSeconds = focus)
        }
    }

    fun setCycles(cycles: Int) {
        if (_uiState.value.isRunning || _uiState.value.hasStarted) return
        _uiState.update { it.copy(totalCycles = cycles.coerceIn(1, 20)) }
    }

    fun setCustomFocus(minutes: Int) {
        if (_uiState.value.hasStarted) return
        _uiState.update { old ->
            val next = old.copy(customFocusMinutes = minutes.coerceIn(5, 180))
            if (next.mode == StudyMode.CUSTOM && next.phase == StudyPhase.FOCUS) {
                next.copy(remainingSeconds = focusSeconds(next), phaseDurationSeconds = focusSeconds(next))
            } else next
        }
    }

    fun setCustomBreak(minutes: Int) {
        if (_uiState.value.hasStarted) return
        _uiState.update { old ->
            val next = old.copy(customBreakMinutes = minutes.coerceIn(1, 60))
            if (next.mode == StudyMode.CUSTOM && next.phase == StudyPhase.BREAK) {
                next.copy(remainingSeconds = breakSeconds(next), phaseDurationSeconds = breakSeconds(next))
            } else next
        }
    }

    fun startOrResume() {
        val current = _uiState.value
        if (current.isFinished || current.isRunning) return
        _uiState.update { it.copy(isRunning = true, hasStarted = true) }
        if (timerJob?.isActive == true) return

        timerJob = viewModelScope.launch {
            while (isActive && _uiState.value.isRunning) {
                delay(1_000)
                val state = _uiState.value
                if (!state.isRunning || state.isFinished) break
                if (state.remainingSeconds > 1) {
                    _uiState.update { it.copy(remainingSeconds = it.remainingSeconds - 1) }
                } else {
                    advancePhase()
                }
            }
        }
    }

    fun pause() {
        _uiState.update { it.copy(isRunning = false) }
        timerJob?.cancel()
        timerJob = null
    }

    fun reset() {
        timerJob?.cancel()
        timerJob = null
        val old = _uiState.value
        val clean = old.copy(
            phase = StudyPhase.FOCUS,
            completedCycles = 0,
            remainingSeconds = focusSeconds(old),
            phaseDurationSeconds = focusSeconds(old),
            isRunning = false,
            hasStarted = false,
            isFinished = false
        )
        _uiState.value = clean
    }

    private fun advancePhase() {
        val state = _uiState.value
        if (state.phase == StudyPhase.FOCUS) {
            val rest = breakSeconds(state)
            _uiState.update {
                it.copy(
                    phase = StudyPhase.BREAK,
                    remainingSeconds = rest,
                    phaseDurationSeconds = rest
                )
            }
        } else {
            val completed = state.completedCycles + 1
            if (completed >= state.totalCycles) {
                _uiState.update {
                    it.copy(
                        completedCycles = completed,
                        remainingSeconds = 0,
                        phaseDurationSeconds = 1,
                        isRunning = false,
                        isFinished = true
                    )
                }
            } else {
                val focus = focusSeconds(state)
                _uiState.update {
                    it.copy(
                        completedCycles = completed,
                        phase = StudyPhase.FOCUS,
                        remainingSeconds = focus,
                        phaseDurationSeconds = focus
                    )
                }
            }
        }
    }

    override fun onCleared() {
        timerJob?.cancel()
        super.onCleared()
    }
}
